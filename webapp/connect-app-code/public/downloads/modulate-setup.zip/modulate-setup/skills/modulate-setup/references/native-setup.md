# Native setup reference

Use the current checked-out runtime documentation and CLI `--help` as the source of truth. Commands below describe agent-operated setup through supported access, not terminal instructions for the customer. Do not use Raspberry Pi Connect or a developer's browser/account as an implicit setup dependency.

## Mac companion

The native bridge targets macOS. Check Python 3.11+, Git and OpenSSL. Create a dedicated virtual environment only when an appropriate one does not already exist. Install the checkout's pinned `requirements-product-host.txt`. Add its computer/camera requirements only for features the user enables. Preserve the current environment and service configuration when repairing an installation.

Studio is started from the repository root with `python -m modulate.studio`. It accepts a literal reachable `--host-address`, the intended Pi's literal `--device-address`, `--state-dir`, optional private `--env-file` and `--connect-env-file`, and an explicit `--budget`. A new installation uses zero until the user authorizes spending; an existing installation retains its actual authorized ceiling and usage/unknown-cost holds. Never copy a developer's historical budget into a new user's installation.

Read existing configuration without displaying its values. Keep credentials in ignored private files with mode 0600 or an appropriate server secret store. The model and ElevenLabs keys belong to the host/server, never the Pi or browser. Verify current provider endpoint/model access rather than assuming the sample model is available to a new account.

Local Studio listens on `http://127.0.0.1:8787` and must be checked on the Mac. It deliberately cannot be reached from the Pi at the Mac's network address; a failed Pi-to-Mac HTTP request on 8787 is not a connectivity diagnosis. The Pi uses a separate certificate-pinned HTTPS endpoint on 8788, with a device credential and exact peer-address check. Verify that path through enrolled telemetry; do not disable TLS checks or authentication to probe it.

The server creates private enrollment and certificate files in the selected state directory. A changed host IP can require a coordinated enrollment update, not a reset of apps or ledgers. Obtain current addresses from the user's supported setup/access path; never recover old addresses or tokens from development logs or backup archives. Complete dependency/configuration preparation while device access is unresolved; do not claim Studio and Pi are connected just because local Studio starts.

## Preloaded gadget: enroll from this Mac

Keep the gadget and Mac on a network that allows them to reach each other. Use a current IPv4 or IPv6 address on the gadget's setup screen; no device browser login or SSH is required. If the screen has no address, resolve its network connection first. Do not guess from historical development IPs. The screen may show an IPv6 address across two lines; join them without spaces. Pass the literal address to the CLI without URL brackets. A shared SSID does not guarantee peer access on isolated guest networks; use a network that permits direct device-to-Mac connections.

1. On the Mac, run `python -m modulate.enroll --device-address <current-screen-address> --print-host-address`. This reads the OS route's source address without sending a network payload.
2. Start Studio using that output as `--host-address`, the gadget's exact address as `--device-address`, and the intended existing state directory, credentials and spending ceiling. Preserve prior state and ledgers; do not create a second installation to avoid an error. If its existing certificate does not match the current Mac address, repair the enrollment/certificate together after a private backup.
3. Run `python -m modulate.enroll --device-address <current-screen-address> --state-dir <existing-state>`, using the same Python environment. Reuse one browser tab for the helper's `http://127.0.0.1:8791` page. The helper reads only the companion's device enrollment and public certificate; it never sends provider credentials or the companion's TLS private key. If the existing helper already reports completion and Studio has fresh device telemetry, skip enrollment entirely.
4. Ask the user to press the small A button to open device setup. Default to direct local-form entry for the full 20-character gadget identity and eight-digit setup code, retaining leading zeroes. If the user has supplied the details and explicitly wants you to enter them, fill and submit the helper yourself subject to your tool's rules. Do not repeatedly hand the same browser step back. The code expires after five minutes; sharing it in the conversation does not by itself prove expiry. Never echo it in progress messages, public logs or screenshots. Agent entry can appear in tool transcripts: do not promise that it remains outside all logs. This code is not a later remote-browser connection code.
5. The helper pins the device's TLS certificate identity before sending enrollment. It stages a request; first show the Mac address and request suffix in the helper, then ask the user to compare them with the gadget and press A freshly to accept or B to reject. Do not simulate this button press. Wait for the helper's matching completion receipt, then move the same browser tab to Studio and verify fresh Pi telemetry. Never call “awaiting confirmation” a completed link.

The gadget setup service is a narrow, temporary enrollment path on TLS port 8790; it does not accept shell commands, runtime updates or caller-chosen file paths. It will not overwrite an existing enrollment. Native Mac pairing still requires another fresh physical confirmation. A remote-browser code follows only if remote access is configured and wanted.

### Recover from the state that exists now

Read the helper's current status before each retry. `complete` means leave the enrollment form and verify Studio; `awaiting_confirmation` means wait for the one physical decision; neither calls for a new code. Check current Studio state as well because the user may have already advanced into pairing while you were inspecting an earlier error.

For `identity_mismatch`, use the reported group/character positions to ask for the smallest physical-screen check needed. A network certificate can identify where the supplied value differs, but cannot authorize replacing the physical identity. Never auto-correct a pin from the network or treat the whole setup as failed because of a transcription error.

For `wrong_code`, check the current code and leading zeroes. For `setup_expired`, `setup_closed` or `attempts_exhausted`, ask for a new setup window once. Legacy `setup_window_unavailable` cannot distinguish expiry from a closed window; describe that uncertainty instead of asserting a cause. For `already_enrolled`, inspect Studio and reuse the existing link; do not erase enrollment. For `device_unreachable`, check the current address/network and preserve state. If an error is unknown, report it as unknown and inspect the relevant implementation; do not cycle through guesses.

An older device whose screen only says **“Enroll this Pi once”** does not have this service. That is a genuine factory/runtime-update blocker, not a code-entry or permission error. Finish Mac preparation, explain that the device needs that update, and stop before claiming a working link. Do not substitute Raspberry Pi Connect, customer shell commands or archived credentials. This source implementation does not prove any particular physical device has been updated or tested.

## Blank Pi / developer-kit installation

This is separate from normal preloaded-gadget setup. Initial Raspberry Pi OS, Wi-Fi and installation access must be provisioned first. Explain the physical SD-card preparation step and establish a supported access method, such as SSH explicitly configured for this user's Mac. Do not erase an existing card without authorization or claim this repository provides a finished Modulate OS image. The agent performs commands once access exists; the customer should not need to edit a Pi remote shell.

Use only an explicitly authorized SSH target/identity or another documented authenticated installation channel. Do not search browser tabs for a logged-in Pi account, silently add SSH keys, reuse revoked access, or ask for remote-terminal command output. Existing OS files and an intentional fresh reset must be respected; missing enrollment after that reset is expected, and old enrollment/pairing must not be restored from backups.

Once authorized access exists, inspect the actual board, SPI/I2C configuration, permissions, screen, microphone and audio output. Only install missing prerequisites. The tested Pi uses OS packages `python3-venv`, `python3-pil`, `python3-lgpio`, `libseccomp2` and `libportaudio2`, a virtual environment with system packages, and `requirements-product-pi.txt`. Prepare faster-whisper's `tiny.en` CPU/int8 cache under the same device user when absent. Do not silently download a different model during a spoken request.

Install the maintained runtime with `python -m modulate.device --state-dir … --enrollment …` using the intended device state directory. The repository includes a systemd template at `deploy/modulate-device.service`; adapt paths and user and avoid two owners of the display/microphone. Once the updated un-enrolled runtime is running, use the physical enrollment flow above. Never transfer the host TLS private key or provider credentials to the Pi.

If this Mac already serves another Pi, determine whether the user is replacing it or wants an additional device before changing the peer address or enrollment. The current host has one exact Pi peer allowlist; do not claim it supports two simultaneous devices. A replacement can retain the host's app library and spending ledgers while updating enrollment separately. Back up the intended existing state privately before making that change.

Do not rewrite peripheral addresses during generic connection setup. If two Qwiic buttons collide, use the runtime's hardware debugger workflow and require isolation/power-cycle confirmation before a supported address write. Power down before changing physical wiring.

## Pair and open the dashboard

Open local Studio after enrollment. Check whether native Mac access is already active before creating a new request. If pending, show the current comparison code on the Mac. Explain once: compare that code with the gadget, then press the small PiTFT A button to authorize Mac access; B declines. If no code is visible on the Mac, repair or update that UI before asking for approval. Do not tell the user to press A twice blindly or use the development `--pair-code` shortcut. macOS Screen Recording, Accessibility, Camera and audio permissions still require the user's system dialogs when needed.

Verify fresh device telemetry and active Mac pairing independently. With those present, local setup is complete at `http://127.0.0.1:8787`; do not withhold success because no remote gateway exists. Explain any unsupported or ungranted feature separately from connection status.

Remote-browser linking is optional and separate. For a configured remote hub, the Pi setup guide or local Studio can display a one-use browser code. It expires after five minutes; the resulting browser session lasts up to eight hours. Never share the code in a public log, URL, artifact, or speech response. If no gateway is configured, do not promise a usable public code or send the user to an unrelated shared demo.

For a user-owned remote deployment, the dedicated gateway binds to loopback port 8789. Use a maintained outbound HTTPS tunnel or equivalent user-owned deployment. The fixed gateway origin and strong independent secrets must match across companion and web server. Never expose ordinary Studio or the Pi endpoint directly. See the repository's `context/connect.md` for the server-only environment names and production-origin configuration.

The shared public demo is currently a single configured hub. No plugin action silently changes that hub to a new user's computer or lends them its provider credentials. A phone can operate the remote dashboard; it cannot grant system-wide control over its own mobile OS.
